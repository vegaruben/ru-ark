
	<footer>
		<div class="col-sm-6">
			<p><strong>© 2016 Voices Mango, All Rights Reserved. </strong><br />
			8560 West Sunset Blvd. |  Suite 500  |  West Hollywood, CA 90069
			</p>  
		</div>
		<div class="col-xs-3 col-sm-2">
			<ul class="footer-links">
			</ul>
		</div>
		<div class="col-xs-3 col-sm-2">
		</div>
		<div class="col-xs-3 col-sm-2">
		</div>
	</footer>

</div> <!-- end container -->
</body>
<script type="text/javascript" src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>

</html>
