<?php
/**
 * Created by PhpStorm.
 * User: aldo
 * Date: 02/11/17
 * Time: 16:55
 */

namespace Funnlz\Services;


class ServiceException extends \RuntimeException
{

}